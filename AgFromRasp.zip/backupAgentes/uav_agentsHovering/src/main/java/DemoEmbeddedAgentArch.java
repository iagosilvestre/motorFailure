import embedded.mas.bridges.jacamo.DefaultEmbeddedAgArch;
import jason.asSyntax.Atom;

public class DemoEmbeddedAgentArch extends DefaultEmbeddedAgArch{

	public DemoEmbeddedAgentArch() {
		super();
	}
				
	
}
